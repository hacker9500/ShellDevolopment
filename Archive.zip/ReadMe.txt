run command ...

gcc 2014100_A1_1.c -o shell
./shell

thats it.